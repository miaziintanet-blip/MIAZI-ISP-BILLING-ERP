-- MIAZI ISP ERP: safe customer import migration
-- Run this once in Supabase SQL Editor AFTER taking a database backup.
-- Phone is intentionally NOT unique because family members may share a phone.

ALTER TABLE public.customers
  ADD COLUMN IF NOT EXISTS customer_code text,
  ADD COLUMN IF NOT EXISTS mac_address text,
  ADD COLUMN IF NOT EXISTS nid text,
  ADD COLUMN IF NOT EXISTS import_key text;

-- Backfill stable keys for existing customers. Phone alone is not treated as identity.
UPDATE public.customers
SET import_key = 'legacy_' || id::text
WHERE import_key IS NULL;

-- Prevent the same import identity from being inserted twice, including concurrent imports.
CREATE UNIQUE INDEX IF NOT EXISTS customers_import_key_uidx
ON public.customers (import_key)
WHERE import_key IS NOT NULL;

-- Helpful lookup indexes; these are deliberately non-unique.
CREATE INDEX IF NOT EXISTS customers_username_lower_idx
ON public.customers (lower(trim(username)))
WHERE username IS NOT NULL AND trim(username) <> '';

CREATE INDEX IF NOT EXISTS customers_mac_address_idx
ON public.customers (upper(trim(mac_address)))
WHERE mac_address IS NOT NULL AND trim(mac_address) <> '';
